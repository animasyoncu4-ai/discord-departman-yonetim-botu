// Gerekli tüm Discord ve Node.js entegrasyon modüllerini en detaylı şekilde tanımlıyoruz
const { 
    Client, 
    GatewayIntentBits, 
    Partials, 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    REST, 
    Routes 
} = require('discord.js');
const fs = require('fs');
const dotenv = require('dotenv');

// Çevresel değişkenleri (.env dosyasından) sistemimize yüklüyoruz
dotenv.config();

// Discord istemcisini tüm yönetimsel intent haklarıyla birlikte başlatıyoruz
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates
    ],
    partials: [
        Partials.Channel,
        Partials.Message
    ]
});

// JSON veri tabanını okuma ve yazma işlemlerini yürüten en detaylı fonksiyonlar
const VERI_TABANI_YOLU = './database.json';

function veriTabaniOku() {
    try {
        const hamVeri = fs.readFileSync(VERI_TABANI_YOLU, 'utf8');
        return JSON.parse(hamVeri);
    } catch (hata) {
        // Eğer dosya boşsa veya hata verirse temiz bir obje döndürüyoruz
        return {};
    }
}

function veriTabaniYaz(veri) {
    try {
        fs.writeFileSync(VERI_TABANI_YOLU, JSON.stringify(veri, null, 4), 'utf8');
    } catch (hata) {
        console.error('[SİSTEM HATASI] Veri tabanına yazılırken bir hata oluştu:', hata);
    }
}

// Bot hazır duruma geldiğinde devreye girecek olan başlatma eventi
client.once('ready', async () => {
    console.log(`[DEPARTMAN SİSTEMİ] ${client.user.tag} başarıyla aktif edildi!`);

    // İtemsatış alıcılarının sunucularına kolayca kurabileceği Slash komut listesi
    const komutlar = [
        {
            name: 'mesai-paneli',
            description: 'Yetkililerin kullanabileceği butonlu mesai giriş/çıkış panelini chate gönderir.'
        },
        {
            name: 'sicil-ekle',
            description: 'Belirtilen memura veya vatandaşa yeni bir sicil/uyarı kaydı işler.',
            options: [
                {
                    name: 'kullanıcı',
                    description: 'Sicil girilecek kişiyi etiketleyin.',
                    type: 6, // USER tipi
                    required: true
                },
                {
                    name: 'detay',
                    description: 'Ceza veya uyarı gerekçesini detaylıca yazınız.',
                    type: 3, // STRING tipi
                    required: true
                }
            ]
        },
        {
            name: 'sicil-görüntüle',
            description: 'Bir kişinin geçmiş sicil ve toplam mesai süresi kayıtlarını listeler.',
            options: [
                {
                    name: 'kullanıcı',
                    description: 'Bilgilerine bakılacak kişiyi etiketleyin.',
                    type: 6, // USER tipi
                    required: true
                }
            ]
        }
    ];

    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

    try {
        console.log('[SİSTEM] Departman komutları API\'ye gönderiliyor...');
        await rest.put(
            Routes.applicationCommands(process.env.CLIENT_ID),
            { body: komutlar }
        );
        console.log('[SİSTEM] Tüm departman komutları başarıyla global olarak yüklendi!');
    } catch (error) {
        console.error('[SİSTEM HATASI] Komutlar yüklenirken hata oluştu:', error);
    }
});

// Slash komut etkileşimlerini yöneten ana fonksiyon yapısı
client.on('interactionCreate', async (interaction) => {
    if (interaction.isChatInputCommand() === false) {
        return;
    }

    const { commandName, options, guildId, user } = interaction;

    // 1. MESAİ PANELİ KOMUTU
    if (commandName === 'mesai-paneli') {
        // Güvenlik doğrulaması: İstersen buraya sadece liderlerin kullanması için rol kontrolü ekleyebilirsin
        const panelEmbed = new EmbedBuilder()
            .setColor('#1e3799')
            .setTitle('👮 DEPARTMAN AKTİFLİK VE MESAİ SİSTEMİ')
            .setDescription('Mesafe kurallarına ve departman hiyerarşisine uymak zorunludur.\n\nMesaiye başlarken ve mesaiyi bitirirken aşağıdaki butonları kullanınız.')
            .addFields(
                { name: '🟢 Aktif Mesai', value: 'Göreve çıkarken bu butona basın ve sürenizi başlatın.', inline: false },
                { name: '🔴 Mesai Bitir', value: 'Görevden ayrılırken veya oyundan çıkarken sürenizi durdurun.', inline: false }
            )
            .setFooter({ text: 'Departman Yönetim Otomasyonu' });

        const baslaButon = new ButtonBuilder()
            .setCustomId('mesai_basla')
            .setLabel('🟢 Göreve Başla (On-Duty)')
            .setStyle(ButtonStyle.Success);

        const bitirButon = new ButtonBuilder()
            .setCustomId('mesai_bitir')
            .setLabel('🔴 Görevi Bitir (Off-Duty)')
            .setStyle(ButtonStyle.Danger);

        const butonSatiri = new ActionRowBuilder().addComponents(baslaButon, bitirButon);

        await interaction.reply({
            embeds: [panelEmbed],
            components: [butonSatiri]
        });
    }

    // 2. SİCİL EKLEME KOMUTU
    if (commandName === 'sicil-ekle') {
        const hedefKullanici = options.getUser('kullanıcı');
        const cezaDetayi = options.getString('detay');

        const db = veriTabaniOku();

        // Eğer bu kullanıcı veri tabanında daha önce hiç kayıt edilmemişse yapısını açıyoruz
        if (!db[hedefKullanici.id]) {
            db[hedefKullanici.id] = {
                toplamMesaiSuresi: 0,
                mesaiBaslangicZamani: null,
                durum: 'Off-Duty',
                sicilKayitlari: []
            };
        }

        // Yeni sicil kaydını ekliyoruz
        const yeniKayit = {
            yetkili: user.tag,
            yetkiliId: user.id,
            icerik: cezaDetayi,
            tarih: new Date().toLocaleString('tr-TR')
        };

        db[hedefKullanici.id].sicilKayitlari.push(yeniKayit);
        veriTabaniYaz(db);

        const basariEmbed = new EmbedBuilder()
            .setColor('#e74c3c')
            .setTitle('📑 Yeni Sicil Kaydı İşlendi')
            .setDescription(`${hedefKullanici} isimli kişinin sicil dosyasına yeni bir ceza/uyarı eklendi.`)
            .addFields(
                { name: '👤 İşlemi Yapan Yetkili', value: `${user.tag}`, inline: true },
                { name: '📝 Ceza Detayı / Gerekçe', value: `${cezaDetayi}`, inline: false }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [basariEmbed] });
    }

    // 3. SİCİL VE MESAİ GÖRÜNTÜLEME KOMUTU
    if (commandName === 'sicil-görüntüle') {
        const hedefKullanici = options.getUser('kullanıcı');
        const db = veriTabaniOku();

        const kullaniciVerisi = db[hedefKullanici.id];

        if (!kullaniciVerisi) {
            return await interaction.reply({
                content: `❌ ${hedefKullanici} isimli kişiye ait departman veri tabanında hiçbir geçmiş kayıt bulunamadı.`,
                ephemeral: true
            });
        }

        // Dakika cinsinden toplam mesai süresini hesaplıyoruz
        const toplamDakika = Math.floor(kullaniciVerisi.toplamMesaiSuresi / 60000);
        
        let sicilMetni = '';
        if (kullaniciVerisi.sicilKayitlari.length === 0) {
            sicilMetni = 'Temiz (Hiç ceza kaydı bulunmuyor).';
        } else {
            kullaniciVerisi.sicilKayitlari.forEach((sicil, indeks) => {
                sicilMetni += `**[${indeks + 1}]** Kurul: ${sicil.tarih}\n↳ **Yetkili:** ${sicil.yetkili}\n↳ **Detay:** ${sicil.icerik}\n\n`;
            });
        }

        const sorguEmbed = new EmbedBuilder()
            .setColor('#2ecc71')
            .setTitle(`🗂️ Departman Dosyası: ${hedefKullanici.username}`)
            .addFields(
                { name: '📊 Mevcut Görev Durumu', value: `\`${kullaniciVerisi.durum}\``, inline: true },
                { name: '⏱️ Toplam Mesai Süresi', value: `\`${toplamDakika} Dakika\``, inline: true },
                { name: '📜 Geçmiş Sicil ve Ceza Dosyası', value: sicilMetni, inline: false }
            )
            .setThumbnail(hedefKullanici.displayAvatarURL());

        await interaction.reply({ embeds: [sorguEmbed] });
    }
});

// Buton etkileşimlerini (Mesaiye başlama ve bitirme) yakalayan event fonksiyonu
client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton() === false) {
        return;
    }

    const { customId, user } = interaction;
    const db = veriTabaniOku();

    // Kullanıcı ilk defa butona basıyorsa yapısını oluşturuyoruz
    if (!db[user.id]) {
        db[user.id] = {
            toplamMesaiSuresi: 0,
            mesaiBaslangicZamani: null,
            durum: 'Off-Duty',
            sicilKayitlari: []
        };
    }

    // GÖREVE BAŞLAMA LOGİC YAPISI
    if (customId === 'mesai_basla') {
        if (db[user.id].durum === 'On-Duty') {
            return await interaction.reply({
                content: '⚠️ Zaten şu anda aktif olarak mesaidesiniz! Tekrar başlatamazsınız.',
                ephemeral: true
            });
        }

        db[user.id].durum = 'On-Duty';
        db[user.id].mesaiBaslangicZamani = Date.now(); // Milisaniye türünden şu anki zamanı kaydediyoruz
        veriTabaniYaz(db);

        await interaction.reply({
            content: '🟢 Başarıyla mesaiye giriş yaptınız. Telsiz kodlarınızı almayı unutmayın. İyi görevler memur bey!',
            ephemeral: true
        });
    }

    // GÖREVİ BİTİRME LOGİC YAPISI
    if (customId === 'mesai_bitir') {
        if (db[user.id].durum === 'Off-Duty' || db[user.id].mesaiBaslangicZamani === null) {
            return await interaction.reply({
                content: '⚠️ Şu anda mesaide değilsiniz. Önce mesaiye başlamalısınız.',
                ephemeral: true
            });
        }

        const gecenSure = Date.now() - db[user.id].mesaiBaslangicZamani;
        
        db[user.id].durum = 'Off-Duty';
        db[user.id].toplamMesaiSuresi = db[user.id].toplamMesaiSuresi + gecenSure;
        db[user.id].mesaiBaslangicZamani = null; // Başlangıç zamanını sıfırlıyoruz
        veriTabaniYaz(db);

        const toplamDakika = Math.floor(gecenSure / 60000);

        await interaction.reply({
            content: `🔴 Mesai başarıyla sonlandırıldı. Bu oturumda toplam **${toplamDakika} dakika** görev yaptınız. Sicilinize işlendi!`,
            ephemeral: true
        });
    }
});

// Botu .env içerisindeki gizli token ile sisteme bağlıyoruz
client.login(process.env.DISCORD_TOKEN);